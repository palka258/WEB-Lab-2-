import React, { useEffect } from "react";
import "./App.css";
import { Button, Card, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

function formatDate(dateString) {
  const options = { month: '2-digit', day: '2-digit', year: 'numeric' };
  return new Intl.DateTimeFormat('en-US', options).format(new Date(dateString));
}

function Todo({ todo, index, markTodo, removeTodo }) {
  return (
    <div className="todo">
      <div className="todo-content">
        <span style={{ textDecoration: todo.isDone ? "line-through" : "" }}>
          {todo.text}
        </span>
        <div className="todo-dates">
          <small>Created: {formatDate(todo.creationDate)}</small><br />
          <small>Due: {todo.dueDate ? formatDate(todo.dueDate) : "No deadline"}</small>
        </div>
      </div>
      <div>
        <Button variant="outline-success" onClick={() => markTodo(index)}>✓</Button>{' '}
        <Button variant="outline-danger" onClick={() => removeTodo(index)}>✕</Button>
      </div>
    </div>
  );
}

function FormTodo({ addTodo }) {
  const [value, setValue] = React.useState("");
  const [dueDate, setDueDate] = React.useState("");

  const handleSubmit = e => {
    e.preventDefault();
    if (!value) return;
    addTodo(value, dueDate);
    setValue("");
    setDueDate("");
  };

  return (
    <Form onSubmit={handleSubmit}> 
      <Form.Group>
        <Form.Label><b>Add Todo</b></Form.Label>
        <Form.Control type="text" className="input" value={value} onChange={e => setValue(e.target.value)} placeholder="Add new todo" />
      </Form.Group>
      <Form.Group>
        <Form.Label><b>Due Date</b></Form.Label>
        <Form.Control type="date" className="input" value={dueDate} onChange={e => setDueDate(e.target.value)} />
      </Form.Group>
      <Button variant="primary" className="mb-3" type="submit">
        Submit
      </Button>
    </Form>
  );
}

function App() {
  const [todos, setTodos] = React.useState([]);

  useEffect(() => {
    const savedTodos = JSON.parse(localStorage.getItem("todos"));
    if (savedTodos) {
      setTodos(savedTodos);
    }
  }, []);

  useEffect(() => {
    if (todos.length > 0) {
      localStorage.setItem("todos", JSON.stringify(todos));
    }
  }, [todos]);

  const addTodo = (text, dueDate) => {
    const creationDate = new Date(); // Store as Date object for consistent formatting
    const newTodos = [...todos, { text, creationDate, dueDate, isDone: false }];
    setTodos(newTodos);
  };

  const markTodo = index => {
    const newTodos = [...todos];
    newTodos[index].isDone = true;
    setTodos(newTodos);
  };

  const removeTodo = index => {
    const newTodos = [...todos];
    newTodos.splice(index, 1);
    setTodos(newTodos);
  };

  return (
    <div className="app">
      <div className="container">
        <h1 className="text-center mb-4">Todo List</h1>
        <FormTodo addTodo={addTodo} />
        <div>
          {todos.map((todo, index) => (
            <Card key={index}>
              <Card.Body>
                <Todo
                  index={index}
                  todo={todo}
                  markTodo={markTodo}
                  removeTodo={removeTodo}
                />
              </Card.Body>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;
